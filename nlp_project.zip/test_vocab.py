import os
from build_vocab import Vocab

train_dir = os.getcwd() + r'\filter_train'
model_path = os.getcwd() + r'\word2vec.model'

model = Vocab().load_word2vec_model(model_path)
vocab = model.wv.vocab
index2word = model.wv.index2word

print(vocab["UNK"].index)
print(index2word[0])

print(index2word[vocab["UNK"].index] == "UNK")
print(index2word[vocab["lol"].index] == "lol")




