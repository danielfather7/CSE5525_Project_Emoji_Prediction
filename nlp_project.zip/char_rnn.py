import numpy as np

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM, Embedding, CuDNNLSTM, SpatialDropout1D, Activation, Bidirectional
from tensorflow.keras.callbacks import ModelCheckpoint

train_file = 'train_char.npy'
train_label = 'train_char_label.npy'
test_file = 'test_char.npy'
test_label = 'test_char_label.npy'


def get_model():
    _vocab_size = 319
    _embedding_size = 300
    _hidden_layer_size = 64

    _model = Sequential()
    _model.add(Embedding(_vocab_size, _embedding_size, input_length=168))
    _model.add(SpatialDropout1D(0.2))
    _model.add(Bidirectional(CuDNNLSTM(_hidden_layer_size)))
    _model.add(Dense(20))
    _model.add(Activation("sigmoid"))
    _model.compile(loss="categorical_crossentropy", optimizer="adam", metrics=["accuracy"])
    _model.summary()
    return _model


X_train = np.load(train_file)
print(X_train.shape)
Y_train = np.load(train_label)
print(Y_train.shape)
X_test = np.load(test_file)
print(X_test.shape)
Y_test = np.load(test_label)
print(Y_test.shape)

model_file_path = r'char_model.weights.best.hdf5'
model = get_model()
print(model)
# model.load_weights(model_file_path)

checkpoint = ModelCheckpoint(filepath=model_file_path, save_best_only=True, verbose=1, monitor='val_acc')
BATCH_SIZE = 4096
history = model.fit(X_train, Y_train,
                    batch_size=BATCH_SIZE * 2,
                    epochs=500,
                    validation_data=(X_test, Y_test),
                    callbacks=[checkpoint])

(loss, accuracy) = model.evaluate(X_test, Y_test)


