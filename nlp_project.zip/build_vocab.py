import os
from gensim.models import Word2Vec
from gensim.test.utils import get_tmpfile


class Vocab:

    def load_word2vec_model(self, _path):
        return Word2Vec.load(_path)

    def build_vocab(self, _dir):
        return Word2Vec(MyFileIterator(_dir), min_count=10, iter=1, size=50)

    def save_model(self, _model, _path):
        _model_path = get_tmpfile(os.getcwd() + _path)
        _model.save(_model_path)

    def train_model(self, dir, _model, _total_examples):
        _model.train(MyTrainIterator(dir), epochs=10, total_examples=_total_examples)


class MyFileIterator:
    def __init__(self, dir_name):
        self.dir_name = dir_name

    def __iter__(self):
        for fname in os.listdir(self.dir_name):
            for line in open(os.path.join(self.dir_name, fname), encoding="utf8"):
                yield line.split()
                yield ["UNK"] * 10


class MyTrainIterator:
    def __init__(self, dir_name):
        self.dir_name = dir_name

    def __iter__(self):
        for fname in os.listdir(self.dir_name):
            for line in open(os.path.join(self.dir_name, fname), encoding="utf8"):
                yield line.split()


# vocab = Vocab()
# model_file_name = r"\word2vec.model"
# train_dir = os.getcwd() + r'\filter_train'
# model_path = os.getcwd() + model_file_name
# cur_model = vocab.build_vocab(_dir=train_dir)
# vocab.train_model(dir=train_dir, _model=cur_model, _total_examples=491665)
# vocab.save_model(_model=cur_model, _path=model_file_name)
# print(cur_model)
#
# model = cur_model
# w1 = "king"
# print(model.wv.most_similar(positive=w1, topn=6))
#
# w1 = "queen"
# print(model.wv.most_similar(positive=w1, topn=6))
#
# w1 = "happy"
# print(model.wv.most_similar(positive=w1, topn=6))
#
# w1 = "dirty"
# print(model.wv.most_similar(positive=w1, topn=6))
#
# w1 = "UNK"
# print(model.wv.most_similar(positive=w1, topn=6))
#
# w1 = "man"
# print(model.wv.most_similar(positive=w1, topn=6))
#
# w1 = "usa"
# print(model.wv.most_similar(positive=w1, topn=6))


# cur_model = vocab.load_word2vec_model(model_path)
# print(cur_model)
