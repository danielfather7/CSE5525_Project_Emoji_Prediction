import os

from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords


class CleanData:

    def read_file_and_tokenize_sentence(self, input_path):
        data = []
        with open(input_path, mode='r', encoding='utf8') as file:
            for tweet in file:
                tweet_words = self.extract_words_from_tweet(tweet)
                data.append(tweet_words)
        print('completed reading the file ', input_path)
        return data

    def extract_words_from_tweet(self, tweet):
        word_list = word_tokenize(tweet)
        final_words = []
        for word in word_list:
            out = ''.join([i for i in word if i.isalpha()])
            if out and len(out) > 2 and out not in self.stop_words:
                final_words.append(out.lower())

        if not final_words:
            final_words.append("NoExpression")

        return final_words

    def filter_and_write_data(self, input_path, output_path):
        data = self.read_file_and_tokenize_sentence(input_path)
        with open(output_path, 'w', encoding="utf8") as file:
            for sentence in data:
                concatenated_sentence = ' '.join(sentence)
                file.write("%s\n" % concatenated_sentence)

    def process_all_files(self, input_path, output_path, limit):
        for i in range(0, limit):
            self.filter_and_write_data(input_path + str(i), output_path + str(i))

    def __init__(self):

        self.stop_words = stopwords.words('english')


clean_data = CleanData()
current_path = os.getcwd()
train_data_prefix = current_path + r"\train" + r"\us_train_0"
filter_train_data_prefix = current_path + r"\filter_train" + r"\us_train_0"

test_data_prefix = current_path + r"\test" + r"\us_test_0"
filter_test_data_prefix = current_path + r"\filter_test" + r"\us_test_0"

clean_data.process_all_files(train_data_prefix, filter_train_data_prefix, 10)
clean_data.process_all_files(test_data_prefix, filter_test_data_prefix, 1)
